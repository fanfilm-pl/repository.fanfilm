from __future__ import annotations
import re
import json
from typing import Any, Tuple, Sequence, Collection, ClassVar, Pattern
from typing_extensions import TypeAlias, Literal
from concurrent.futures import ThreadPoolExecutor
from attrs import define

from ..ff import requests
from ..ff.log_utils import fflog
from ..ff.item import FFItem
from ..ff.types import JsonData
from ..defs import MediaRef, VideoIds, RefType, ItemList
from ..kolang import L

ImdbTitleType: TypeAlias = Literal['feature', 'tv_series', 'short', 'tv_episode', 'tv_miniseries',
                                   'tv_movie', 'tv_special', 'tv_short', 'video_game', 'video',
                                   'music_video', 'podcast_series', 'podcast_episode']

UA = 'Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)'


ImdbListType = Literal['TITLES', 'PEOPLE', 'VIDEOS', 'IMAGES']


@define
class ImdbApiStats:
    request_count: int = 0


@requests.netcache('lists')
class ImdbScraper:

    PATTERN: ClassVar[Pattern[str]] = re.compile(r'<script\s+id="__NEXT_DATA__"\s+type="application/json">(.*?)<\/script>', re.DOTALL)

    MEDIA_TYPES: ClassVar[dict[str, RefType]] = {
        'movie': 'movie',
        'short': 'movie',
        'tvMovie': 'movie',
        'tvShort': 'movie',
        'tvSpecial': 'movie',
        'video': 'movie',
        'videoGame': 'movie',
        'musicVideo': 'movie',
        'tvSeries': 'show',
        'tvMiniSeries': 'show',
        'podcastSeries': 'show',
        'tvEpisode': 'episode',
        'podcastEpisode': 'episode',
    }

    TITLE_TYPES: ClassVar[dict[RefType, Collection[ImdbTitleType]]] = {
        'movie':   ('feature', 'short', 'tv_movie', 'tv_short', 'tv_special'),
        'show':    ('tv_series', 'tv_miniseries'),
        'episode': ('tv_episode',),
        # 'movie':   ('feature', 'short', 'tv_movie', 'tv_short', 'tv_special', 'video', 'video_game', 'music_video'),
        # 'show':    ('tv_series', 'tv_miniseries', 'podcast_series'),
        # 'episode': ('tv_episode', 'podcast_episode'),
    }

    _DEBUG_STATS: ClassVar[ImdbApiStats] = ImdbApiStats()
    _FAKE: ClassVar[bool] = False

    def __init__(self) -> None:
        self.headers = {"User-Agent": UA}
        # title_type = feature, tv_series, short, tv_episode, tv_miniseries, tv_movie, tv_special, tv_short,
        #              video_game, video,music_video, podcast_series, podcast_episode
        self.url: str = 'https://www.imdb.com/'

    def get_html(self, url: str, params: dict[str, Any] | None = None) -> str | None:
        fflog(f'Get from {url}')
        self._DEBUG_STATS.request_count += 1
        if self._FAKE:
            return None
        req = requests.get(url, headers=self.headers, params=params)
        if req.status_code != 200:
            return None
        return req.text

    def get_json(self, url: str, params: dict[str, Any] | None = None) -> JsonData:
        html: str | None = self.get_html(url, params=params)
        if html is not None:
            if mch := self.PATTERN.search(html):
                return json.loads(mch.group(1)).get("props", {}).get("pageProps", {})
        return {}

    @requests.netcache('discover')
    def last_oscars_refs(self,
                         name: str = 'oscar_winner',
                         *,
                         title_type: ImdbTitleType | Collection[ImdbTitleType] | None = None,
                         ) -> list[MediaRef]:
        params = {
            'sort': 'year,desc',
            'count': 250,
            'groups': name,
        }
        if title_type:
            if isinstance(title_type, str):
                params['title_type'] = title_type
            else:
                params['title_type'] = ','.join(title_type)
        if json_object := self.get_json(f'{self.url}search/title/', params=params):
            data: list[JsonData] = json_object.get("searchResults", {}).get("titleResults", {}).get("titleListItems", [])
            return [VideoIds(imdb=it['titleId']).ref(ref_type) for it in data if (ref_type := self.MEDIA_TYPES.get(it['titleType']['id']))]
        return []

    def _get_list(self, url_path: str, *, data_key: str, media_type: RefType | None = None, page: int | None = 0) -> list[MediaRef]:
        def get(page: int | None = 0) -> Tuple[Sequence[JsonData], int]:
            params = {'count': 250}
            if page:
                params['page'] = page
            if data := self.get_json(f'{self.url}{url_path}', params=params):
                if imdb_list := data.get('mainColumnData', {}).get(data_key, {}):
                    # imdb_list['id']
                    # imdb_list['createdDate']
                    # imdb_list['lastModifiedDate']
                    # imdb_list['author'] = {}
                    if items_data := imdb_list.get('titleListItemSearch', {}):
                        return [node for edge in items_data.get('edges', []) if (node := edge.get('listItem', {}))], items_data.get('total', 0)
            return [], 0

        items, total = get(page)
        return ItemList((MediaRef(media, VideoIds.make_ffid(imdb=node['id']))
                         for node in items
                         if (media := self.MEDIA_TYPES.get(node['titleType']['id'])) and (not media_type or media_type == media)),
                        page=page or 1, total_pages=(total + len(items) - 1) // max(1, len(items)), total_results=total)

    def _user(self, user: str) -> Sequence[str]:
        return [f'ur{usr}' if usr.isdecimal() else usr for name in user.split(',') if (usr := name.strip())]

    def watch_list(self, user: str, *, media_type: RefType | None = None, page: int | None = None) -> list[MediaRef]:
        users = self._user(user)
        if users:
            user = users[0]
            return self._get_list(f'/user/{user}/watchlist/', data_key='predefinedList', media_type=media_type, page=page)
        return []

    def list(self, list_id: str, *, media_type: RefType | None = None, page: int | None = None) -> list[MediaRef]:
        if list_id.isdecimal():
            list_id = f'ls{list_id}'
        return self._get_list(f'/list/{list_id}/', data_key='list', media_type=media_type, page=page)

    def user_lists(self, user: str) -> list[FFItem]:
        def make_item(node: JsonData) -> FFItem:
            def var(*keys: str) -> Any:
                val: Any = node
                for key in keys:
                    if not isinstance(val, dict):
                        return None
                    val = val.get(key)
                return val
            name = node['name']['originalText']
            # ref = MediaRef('list', VideoIds.make_ffid(imdb=node['id']))
            ffitem = FFItem(name, mode=FFItem.Mode.Folder)
            ffitem.title = name
            ffitem.vtag.setUniqueID(node['id'], 'imdb')
            ffitem.vtag.setIMDBNumber(node['id'])
            if descr := var('description', 'originalText', 'plainText'):
                ffitem.vtag.setPlot(descr)
            if img := var('primaryImage', 'image'):
                ffitem.setArt({'poster': img['url']})
            if count := node.get('items'):
                ffitem._children_count = count['total']
                ffitem.role = L(30331, '{n} title|||{n} titles', n=count['total'])
                if len(users) > 1 and (author := var('author', 'username', 'text')):
                    ffitem.role += f', {author}'
            # createdDate, lastModifiedDate
            return ffitem

        def get_lists(user: str, page: int | None = None) -> list[FFItem]:
            params = {'count': 250, 'type': 'titles'}
            if page:
                params['page'] = page  # NOTE: IMDB ignores page parameter for user lists, web uses graphql with pagination hidden by ClaodFlare
            if data := self.get_json(f'{self.url}/user/{user}/lists/', params=params):
                # print(json.dumps(data, indent=2))
                if imdb_list := data.get('mainColumnData', {}).get('userListSearch', {}):
                    return [make_item(node)
                            for edge in imdb_list.get('edges', [])
                            if (node := edge.get('node', {})) and node['listType']['id'] == 'TITLES']  # skip images, people, videos
                            # if (node := edge.get('node', {}))]  # and node['listType']['id'] == 'TITLES']
            return []

        users = self._user(user)
        with ThreadPoolExecutor() as executor:
            results = list(executor.map(get_lists, users))
        return [it for sublist in results for it in sublist]

    def user_info_list(self, user: str) -> list[FFItem]:
        def get(user: str) -> FFItem | None:
            def var(*keys: str, default: Any = None) -> Any:
                val: Any = data
                for key in keys:
                    if not isinstance(val, dict):
                        return default
                    val = val.get(key, ...)
                    if val is ...:
                        return default
                return val
            if data := self.get_json(f'{self.url}/user/{user}'):
                imdb = data['userId']
                name = var('userNickName', 'value', default=user)
                ffitem = FFItem(name, mode=FFItem.Mode.Folder)
                ffitem.title = name
                ffitem.vtag.setUniqueID(imdb, 'imdb')
                ffitem.vtag.setIMDBNumber(imdb)
                if img := var('imageData', 'model'):
                    ffitem.setArt({'poster': img['url']})
                if bio := var('bio', 'value'):
                    ffitem.vtag.setPlot(bio)
                if count := var('listData'):
                    ffitem.role = L(30331, '{n} title|||{n} titles', n=count['total'])
                return ffitem

        users = self._user(user)
        with ThreadPoolExecutor() as executor:
            results = list(executor.map(get, users))
        return [it for it in results if it]

    def user_info(self, user: str) -> FFItem | None:
        """Get user info as FFItem (first user if user is comma separated list)."""
        items = self.user_info_list(user)
        return items[0] if items else None


if __name__ == '__main__':
    from math import log10
    from contextlib import contextmanager
    from typing import TypeVar, Iterator
    from wrapt import ObjectProxy
    from ..ff.cmdline import DebugArgumentParser

    T = TypeVar('T')

    class ItemProxy(ObjectProxy):
        def __init__(self, item: T, *, index: int, width: int = 0) -> None:
            super().__init__(item)
            self._self_index = index
            self._self_width = width

        @property
        def num(self) -> str:
            return f'{self._self_index:{self._self_width}d}'

    @contextmanager
    def enum(items: Sequence[T], *, offset: int = 0, page: int | None = None, page_size: int = 250) -> Iterator[Sequence[T]]:
        if not offset and page and page_size:
            offset = ((page or 1) - 1) * page_size
        w = int(1 + log10(offset + len(items) or 1))
        items = [ItemProxy(it, index=i, width=w) for i, it in enumerate(items, offset + 1)]
        yield items

    p = DebugArgumentParser()
    p.add_argument('-w', '--watchlist', help='IMDB user ID like ur123456789')
    p.add_argument('-u', '--user', help='IMDB user ID like ur23892615')
    p.add_argument('-l', '--list', help='IMDB list ID like ls005762314')
    p.add_argument('-p', '--page', type=int, help='IMDB list ID like ls123456789')
    p.add_argument('-d', '--depaginate', action='store_true', help='depaginate list')
    p.add_argument('-i', '--info', action='store_true', help='get info for: user (-u), ...')
    args = p.parse_args()

    # ur23892615  - 1967 title lists (3719 all types)
    # ls005762314 - 519 items, 3 pages

    imdb = ImdbScraper()
    if args.watchlist:
        items = imdb.watch_list(args.watchlist, page=args.page)
        with enum(items) as items:
            for ref in items:
                print(f'{ref.num}. {ref}')
    elif args.user:
        if args.info:
            items = imdb.user_info_list(args.user)
            w = int(1 + log10(len(items) or 1))
            for i, it in enumerate(items, 1):
                print(f'{i:{w}d}. {it.vtag.getIMDBNumber():12}: {it.label} [{it.role}]')
        else:
            items = imdb.user_lists(args.user)
            w = int(1 + log10(len(items) or 1))
            for i, it in enumerate(items, 1):
                print(f'{i:{w}d}. {it.vtag.getIMDBNumber():12} [{it.role}] {it}')
    elif args.list:
        if args.depaginate:
            from . import depaginate
            with depaginate(imdb) as api:
                items = api.list(args.list)
                w = int(1 + log10(len(items) or 1))
                for i, ref in enumerate(items, 1):
                    print(f'{i:{w}d}. {ref}')
        else:
            items = imdb.list(args.list, page=args.page)
            start = ((args.page or 1) - 1) * 250
            w = int(1 + log10(start + len(items) or 1))
            for i, ref in enumerate(items, start + 1):
                print(f'{i:{w}d}. {ref}')
    else:
        for ref in imdb.last_oscars_refs():
            print(ref)
